package com.sb.workcalendar; public class ScheduleWidget extends WidgetBase {int mode(){return 2;}String title(){return "오늘 · 스케줄";}}
