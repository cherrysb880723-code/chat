package com.sb.workcalendar; public class CombinedWidget extends WidgetBase {int mode(){return 0;}String title(){return "오늘 · 통합";}}
