오디오 분석기 Android 앱 프로젝트 v1

포함 기능
- 홈 화면/앱 서랍에 '오디오 분석기' 아이콘 표시
- 확정한 파랑→보라→핑크 5-bar 파형 앱 아이콘
- v21 분석기 UI/분석 엔진을 앱 내부 assets에 포함
- 인터넷 없이 분석 가능
- Android 파일 선택창에서 오디오/영상 여러 개 선택 가능

APK 만드는 방법
1. Android Studio에서 이 폴더를 Open 합니다.
2. Gradle Sync가 끝날 때까지 기다립니다.
3. Build > Build App Bundles or APKs > Build APKs
4. 생성된 app-debug.apk를 휴대폰으로 옮겨 설치합니다.

현재 이 실행 환경에는 Android SDK/Gradle 빌드 도구가 설치되어 있지 않아 여기서 APK 바이너리 자체를 컴파일할 수는 없습니다.
프로젝트는 Android Studio에서 바로 빌드할 수 있는 형태로 구성했습니다.
