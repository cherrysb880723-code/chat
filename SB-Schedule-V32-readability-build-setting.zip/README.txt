SB스케줄 V32 빌드 설정

변경사항
- 앱 달력 글꼴을 sans-serif 계열로 고정해 기기 글꼴 영향 최소화
- 날짜/요일/근무/일정/근무변경 내용 글자 굵기와 크기 강화
- 월 제목과 탭 가독성 강화
- 위젯 날짜/근무/일정 글꼴도 동일 계열로 통일하고 크기/대비 강화

GitHub의 .github/workflows 폴더에 build-sb-schedule-v32.yml 파일을 올린 뒤 Actions에서 실행하세요.
