package com.sb.workcalendar; public class ScheduleMonthWidget extends WidgetBase{int mode(){return 2;}boolean monthView(){return true;}String title(){return "SB스케줄 · 일정";}}
