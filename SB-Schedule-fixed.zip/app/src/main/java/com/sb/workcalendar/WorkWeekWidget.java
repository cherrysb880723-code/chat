package com.sb.workcalendar; public class WorkWeekWidget extends WidgetBase{int mode(){return 1;}boolean monthView(){return false;}String title(){return "SB스케줄 · 근무 7일";}}
