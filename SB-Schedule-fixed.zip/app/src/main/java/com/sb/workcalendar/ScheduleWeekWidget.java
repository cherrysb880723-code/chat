package com.sb.workcalendar; public class ScheduleWeekWidget extends WidgetBase{int mode(){return 2;}boolean monthView(){return false;}String title(){return "SB스케줄 · 일정 7일";}}
