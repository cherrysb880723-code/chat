package com.sb.workcalendar; public class WorkWidget extends WidgetBase {int mode(){return 1;}String title(){return "오늘 · 근무";}}
