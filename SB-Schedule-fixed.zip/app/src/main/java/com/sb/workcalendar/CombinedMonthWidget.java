package com.sb.workcalendar; public class CombinedMonthWidget extends WidgetBase{int mode(){return 0;}boolean monthView(){return true;}String title(){return "SB스케줄 · 통합";}}
