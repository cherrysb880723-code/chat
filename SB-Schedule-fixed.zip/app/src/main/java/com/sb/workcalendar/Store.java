package com.sb.workcalendar;
import android.content.*;import org.json.*;import java.nio.charset.StandardCharsets;import java.security.*;import java.time.*;import java.time.temporal.ChronoUnit;
public class Store {
 static final String[] PATTERN={"막방","막방","막전","막전","휴무","휴무","주상","주상","야상","야상","휴무","휴무","둘방","둘방","첫방","첫방","휴무","휴무"};
 static final LocalDate BASE=LocalDate.of(2026,8,23); final android.content.SharedPreferences p;
 Store(Context c){p=c.getSharedPreferences("private_calendar",Context.MODE_PRIVATE);}
 int team(){return p.getInt("team",0);} void setTeam(int n){p.edit().putInt("team",n).apply();}
 String teamName(int i){return p.getString("team_name_"+i,(i+1)+"조 ("+(char)('A'+i)+"조)");}void setTeamName(int i,String s){p.edit().putString("team_name_"+i,s).apply();}
 String duty(LocalDate d){String v=p.getString("duty_"+d,null);if(v!=null)return v;long n=ChronoUnit.DAYS.between(BASE,d)+team()*2;return PATTERN[Math.floorMod((int)n,18)];}
 void setDuty(LocalDate d,String v){android.content.SharedPreferences.Editor e=p.edit();if("자동 근무로 복원".equals(v))e.remove("duty_"+d);else e.putString("duty_"+d,v);e.apply();}
 JSONObject event(LocalDate d){try{return new JSONObject(p.getString("event_"+d,"{}"));}catch(Exception e){return new JSONObject();}}
 void setEvent(LocalDate d,String title,String memo,boolean secret){try{if(title.isEmpty()&&memo.isEmpty()){p.edit().remove("event_"+d).apply();return;}JSONObject o=new JSONObject();o.put("title",title);o.put("memo",memo);o.put("secret",secret);p.edit().putString("event_"+d,o.toString()).apply();}catch(Exception ignored){}}
 boolean hasPin(){return p.contains("pin_hash");}void setPin(String pin){p.edit().putString("pin_hash",hash(pin)).apply();}boolean checkPin(String pin){return p.getString("pin_hash","").equals(hash(pin));}
 private String hash(String s){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format("%02x",v));return x.toString();}catch(Exception e){return "";}}
}
