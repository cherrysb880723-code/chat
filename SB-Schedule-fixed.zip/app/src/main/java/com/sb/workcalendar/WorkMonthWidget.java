package com.sb.workcalendar; public class WorkMonthWidget extends WidgetBase{int mode(){return 1;}boolean monthView(){return true;}String title(){return "SB스케줄 · 근무";}}
